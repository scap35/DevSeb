#!/bin/sh 
# @author Zoumana TRAORE
# @comment: Shell script to launch the XML generator jar binary
java   -jar xmlgenerators-core-1.1.3.one-jar.jar $*